
// Represents a Bank with list of accounts
class Bank {
    
  String name;
  ILoAccount accounts;
    
  Bank(String name, ILoAccount accounts) {
    this.name = name;
    this.accounts = accounts;
  }

}
