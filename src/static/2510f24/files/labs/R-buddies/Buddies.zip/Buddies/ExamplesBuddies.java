import tester.*;


// runs tests for the buddies problem
public class ExamplesBuddies{

}